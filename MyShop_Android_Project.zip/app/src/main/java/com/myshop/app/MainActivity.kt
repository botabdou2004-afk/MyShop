package com.myshop.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.camera.view.PreviewView
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var totalText: TextView
    private lateinit var statusText: TextView
    private lateinit var salesText: TextView
    private val prefs by lazy { getSharedPreferences("myshop_data", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private var lastBarcode = ""
    private var lastScanAt = 0L
    private val scanner by lazy { BarcodeScanning.getClient() }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        totalText = findViewById(R.id.totalText)
        statusText = findViewById(R.id.statusText)
        salesText = findViewById(R.id.salesText)

        if (prefs.getString("sales_date", "") != today()) {
            prefs.edit().putString("sales_json", "[]").putString("sales_date", today()).apply()
        }
        refreshSummary()

        findViewById<Button>(R.id.manualButton).setOnClickListener { manualEntry() }
        findViewById<Button>(R.id.resetButton).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("إنهاء يوم العمل؟")
                .setMessage("سيتم حذف مبيعات اليوم فقط. ستبقى أسماء وأسعار السلع محفوظة.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إنهاء اليوم") { _, _ ->
                    saveSales(JSONArray())
                    refreshSummary()
                    statusText.text = "تم تصفير مبيعات اليوم"
                }.show()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera()
        else statusText.text = "يجب السماح باستخدام الكاميرا لمسح الباركود"
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy -> scanFrame(proxy) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (_: Exception) { statusText.text = "تعذر تشغيل الكاميرا" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scanFrame(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null) { proxy.close(); return }
        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { codes ->
                val value = codes.firstOrNull()?.rawValue ?: return@addOnSuccessListener
                val now = System.currentTimeMillis()
                if (value != lastBarcode || now - lastScanAt > 1800) {
                    lastBarcode = value
                    lastScanAt = now
                    runOnUiThread { handleBarcode(value) }
                }
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun products(): JSONObject {
        return try { JSONObject(prefs.getString("products_json", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    }
    private fun sales(): JSONArray {
        return try { JSONArray(prefs.getString("sales_json", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    }
    private fun saveProducts(value: JSONObject) { prefs.edit().putString("products_json", value.toString()).apply() }
    private fun saveSales(value: JSONArray) {
        prefs.edit().putString("sales_json", value.toString()).putString("sales_date", today()).apply()
    }

    private fun handleBarcode(code: String) {
        val product = products().optJSONObject(code)
        if (product != null) {
            addSale(code, product.optString("name"), product.optDouble("price"))
        } else {
            productDialog(code, "", "")
        }
    }

    private fun productDialog(code: String, initialName: String, initialPrice: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 10, 40, 0) }
        val name = EditText(this).apply { hint = "اسم السلعة"; setText(initialName) }
        val price = EditText(this).apply { hint = "السعر بالدينار"; inputType = 8194; setText(initialPrice) }
        box.addView(name); box.addView(price)
        AlertDialog.Builder(this).setTitle("سلعة جديدة\nالباركود: $code").setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ وإضافة") { _, _ ->
                val n = name.text.toString().trim()
                val p = price.text.toString().toString().replace(',', '.').toDoubleOrNull()
                if (n.isEmpty() || p == null || p < 0) {
                    Toast.makeText(this, "أدخل اسمًا وسعرًا صحيحين", Toast.LENGTH_LONG).show()
                } else {
                    val all = products()
                    all.put(code, JSONObject().put("name", n).put("price", p))
                    saveProducts(all)
                    addSale(code, n, p)
                }
            }.show()
    }

    private fun addSale(code: String, name: String, price: Double) {
        val list = sales()
        var found = false
        for (i in 0 until list.length()) {
            val row = list.optJSONObject(i) ?: continue
            if (row.optString("barcode") == code) {
                row.put("qty", row.optInt("qty", 0) + 1)
                found = true
                break
            }
        }
        if (!found) list.put(JSONObject().put("barcode", code).put("name", name).put("price", price).put("qty", 1))
        saveSales(list)
        refreshSummary()
        statusText.text = "$name — تمت إضافة قطعة"
    }

    private fun manualEntry() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 10, 40, 0) }
        val code = EditText(this).apply { hint = "الباركود (أو رمز يدوي)" }
        val name = EditText(this).apply { hint = "اسم السلعة" }
        val price = EditText(this).apply { hint = "السعر بالدينار"; inputType = 8194 }
        box.addView(code); box.addView(name); box.addView(price)
        AlertDialog.Builder(this).setTitle("إضافة سلعة يدويًا").setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ وإضافة") { _, _ ->
                val c = code.text.toString().trim()
                val n = name.text.toString().trim()
                val p = price.text.toString().replace(',', '.').toDoubleOrNull()
                if (c.isEmpty() || n.isEmpty() || p == null || p < 0) {
                    Toast.makeText(this, "أكمل البيانات بشكل صحيح", Toast.LENGTH_LONG).show()
                } else {
                    val all = products()
                    all.put(c, JSONObject().put("name", n).put("price", p))
                    saveProducts(all)
                    addSale(c, n, p)
                }
            }.show()
    }

    private fun refreshSummary() {
        val list = sales()
        var total = 0.0
        val lines = StringBuilder()
        for (i in 0 until list.length()) {
            val row = list.optJSONObject(i) ?: continue
            val amount = row.optDouble("price") * row.optInt("qty")
            total += amount
            lines.append(row.optString("name")).append(" × ").append(row.optInt("qty"))
                .append(" = ").append(String.format(Locale.US, "%.2f", amount)).append(" دج\n")
        }
        totalText.text = "إجمالي اليوم: ${String.format(Locale.US, "%.2f", total)} دج"
        salesText.text = if (lines.isEmpty()) "لا توجد مبيعات بعد" else lines.toString()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        scanner.close()
    }
}
